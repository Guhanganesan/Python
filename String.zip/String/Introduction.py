name="Guhan Ganesan"
msg='Hi guhan how are you'

email =""" Subject: Regarding..
           I am going to attend on interview....
"""

addr='''  G. Guhan
          Velachery
          Chennai
          600042
'''

print(name)

print(msg)

print(email)

print(addr)
